package com.elyon_yireh.surveys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveysApplicationTests {

	@Test
	void contextLoads() {
	}

}
